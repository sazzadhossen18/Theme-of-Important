/* ========================================================================
   INFORMATIONS GÉNÉRALES SUR LE SITE
   Propriété de © 2019/2024 Shopiweb.fr
   Pour plus d'informations, visitez : https://www.shopiweb.fr
   ======================================================================== */

console.log(
  "Shopiweb Theme - Premium Shopify Theme by shopiweb.fr | En savoir plus sur https://www.shopiweb.fr"
);

/* =====================
   Détection défilement page
   ===================== */
window.addEventListener("scroll", (event) => {
  if (window.scrollY > 0) {
    document.documentElement.classList.add("has-scrolled");
  } else {
    document.documentElement.classList.remove("has-scrolled");
  }
});

/* =====================
   Bootstrap tooltips
   ===================== */
document
  .querySelectorAll('[data-bs-toggle="tooltip"]')
  .forEach((el) => new bootstrap.Tooltip(el));

/* =====================
   Bootstrap popovers
   ===================== */
document
  .querySelectorAll('[data-bs-toggle="popover"]')
  .forEach((el) => new bootstrap.Popover(el));

/* =====================
   Page d'appel Shopify - Ajouter des classes BS
   ===================== */
document
  .querySelector(".btn.shopify-challenge__button")
  ?.classList.add("btn-primary");

/* =====================
   Messages d'erreur de Shopify - Ajouter des classes BS
   ===================== */
const errors = document.querySelector(".errors");
if (errors) {
  errors.classList.add("alert", "alert-danger");
}

/* =====================
   Redimensionner les images Shopify
   ===================== */
Shopify.resizeImage = (src, size, crop = "") =>
  src
    .replace(
      /_(pico|icon|thumb|small|compact|medium|large|grande|original|1024x1024|2048x2048|master)+\./g,
      "."
    )
    .replace(/\.jpg|\.png|\.gif|\.jpeg/g, (match) => {
      if (crop.length) {
        // eslint-disable-next-line no-param-reassign
        crop = `_crop_${crop}`;
      }
      return `_${size}${crop}${match}`;
    });

/* =====================
   Format monétaire de Shopify
   ===================== */
Shopify.formatMoney = function (cents, format) {
  if (typeof cents === "string") {
    cents = cents.replace(".", "");
  }

  let value = "";
  const placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  const formatString = format || this.money_format;

  function defaultOption(opt, def) {
    return typeof opt === "undefined" ? def : opt;
  }

  function formatWithDelimiters(number, precision, thousands, decimal) {
    precision = defaultOption(precision, 2);
    thousands = defaultOption(thousands, ",");
    decimal = defaultOption(decimal, ".");

    if (isNaN(number) || number == null) {
      return 0;
    }

    number = (number / 100.0).toFixed(precision);

    const parts = number.split(".");
    const dollars = parts[0].replace(
      /(\d)(?=(\d\d\d)+(?!\d))/g,
      "$1" + thousands
    );
    const cents = parts[1] ? decimal + parts[1] : "";

    return dollars + cents;
  }

  switch (formatString.match(placeholderRegex)[1]) {
    case "amount":
      value = formatWithDelimiters(cents, 2);
      break;
    case "amount_no_decimals":
      value = formatWithDelimiters(cents, 0);
      break;
    case "amount_with_comma_separator":
      value = formatWithDelimiters(cents, 2, ".", ",");
      break;
    case "amount_no_decimals_with_comma_separator":
      value = formatWithDelimiters(cents, 0, ".", ",");
      break;
  }

  return formatString.replace(placeholderRegex, value);
};

/* =====================
   Débouclage
   ===================== */
window.debounce = (callback, wait = 200) => {
  let timeout;
  return (...args) => {
    const context = this;
    clearTimeout(timeout);
    timeout = setTimeout(() => callback.apply(context, args), wait);
  };
};

/* =====================
   Accélérateur
   ===================== */
window.throttle = (callback, timeFrame = 200) => {
  let lastTime = 0;
  return function () {
    const now = Date.now();
    if (now - lastTime >= timeFrame) {
      callback();
      lastTime = now;
    }
  };
};

/* =====================
   Détecter les éléments lorsqu'ils sont visibles
   ===================== */
const initializeEnterView = () => {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("entered");

          entry.target
            .querySelectorAll(".animate__animated.opacity-0")
            .forEach((el) => {
              el.classList.remove("opacity-0");
              el.classList.add(el.dataset.animateClass);
            });
        }
      });
    },
    { threshold: 0, rootMargin: "0px 0px -200px 0px" }
  );

  document.querySelectorAll(".enter-view").forEach((el) => {
    observer.observe(el);
  });
};
initializeEnterView();

/* =====================
   Créer un cookie
   ===================== */
window.createNewCookie = (name, value, days) => {
  let date, expires;
  if (days) {
    date = new Date();
    date.setDate(date.getDate() + days);
    expires = "; expires=" + date.toUTCString();
  } else {
    expires = "";
  }
  document.cookie = name + "=" + value + expires + "; path=/";
};

/* =====================
   Bouton de défilement vers le haut général
   ===================== */
const initializeScrollToTopButton = () => {
  const btn = document.querySelector("#btn-scroll-top");

  if (!btn) return;

  document.addEventListener(
    "scroll",
    window.throttle(() => {
      if (window.scrollY > Number(btn.dataset.scroll)) {
        btn.classList.add("btn-show");
      } else {
        btn.classList.remove("btn-show");
      }
    }, 700)
  );
};
initializeScrollToTopButton();

/* =====================
   Lazy load HTMl5 videos
   ===================== */
const initializeVideoLazyLoad = () => {
  const lazyVideos = [].slice.call(
    document.querySelectorAll("video.lazy-video")
  );

  if ("IntersectionObserver" in window) {
    const lazyVideoObserver = new IntersectionObserver(
      function (entries, observer) {
        entries.forEach(function (video) {
          if (video.isIntersecting) {
            for (const source in video.target.children) {
              const videoSource = video.target.children[source];
              if (
                typeof videoSource.tagName === "string" &&
                videoSource.tagName === "SOURCE"
              ) {
                videoSource.src = videoSource.dataset.src;
              }
            }

            video.target.load();

            if (video.target.hasAttribute("data-poster")) {
              video.target.poster = video.target.dataset.poster;
            }

            video.target.classList.remove("lazy-video");
            lazyVideoObserver.unobserve(video.target);
          }
        });
      },
      { threshold: 0, rootMargin: "0px 0px 200px 0px" }
    );

    lazyVideos.forEach(function (lazyVideo) {
      lazyVideoObserver.observe(lazyVideo);
    });
  }
};
initializeVideoLazyLoad();

document.addEventListener("shopify:section:load", () => {
  document.querySelectorAll(".enter-view").forEach((elem) => {
    elem.classList.add("entered");
    document.querySelectorAll(".animate__animated.opacity-0").forEach((el) => {
      el.classList.remove("opacity-0");
    });
  });
});
